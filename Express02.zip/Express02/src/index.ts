import express, { Request, Response } from 'express'
import { Iuser } from './type/type.user'
import { v4 as uuidv4 } from 'uuid';

const app = express()
app.use(express.json())

let user: Iuser[] = [

    {
        id: '1',
        username: 'john',
        password: '123',
        email: 'test@gmail.com'
    }
]



app.get('/api/get', (req: Request, res: Response) => {
    res.json(user)
})

app.post('/api/post', (req: Request, res: Response) => {
    const newuser = req.body as Iuser
    newuser.id = uuidv4()
    user.push(newuser)
    res.json('user added')
})


app.listen(3000, () => {
    console.log(' server listing 3000');

})